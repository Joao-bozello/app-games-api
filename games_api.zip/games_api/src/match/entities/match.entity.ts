import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm';
@Entity()
export class Match {
    @PrimaryGeneratedColumn()
    id: number;
    @Column('int')
    player1: number;
    @Column('int') 
    player2: number;
    @Column('int') 
    game:  number;
    @Column('int') 
    time: number;
    @Column('int')
    winner: number;

}

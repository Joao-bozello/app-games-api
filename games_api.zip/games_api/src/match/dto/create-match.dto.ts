export class CreateMatchDto {

 


    player1: number;

    player2: number;

    game: number;
    time: number;

    winner: number;
}

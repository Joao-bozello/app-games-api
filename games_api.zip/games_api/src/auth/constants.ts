export const jwtConstants = {
    secret: '123123123123',
  };
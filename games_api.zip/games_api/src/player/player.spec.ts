import { Test, TestingModule } from '@nestjs/testing';
import { playerProviders} from './player.providers';

describe('Player', () => {
  
});

export class CreatePlayerDto {

 
    id: number | null;

    nickname: string| null;

    email: string| null;

    password: string| null;
  
    birthday: string| null;
    
 
    name: string | null;
}

export class CreateGameDto {



 
    name: string | null;

    censorship: string | null; 
    type: string | null;
  
    playerNumber: number |null

}

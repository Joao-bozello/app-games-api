import { MigrationInterface, QueryRunner } from "typeorm"

export class Migrations1687205752699 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<void> {
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
    }

}


## Description



## Installation
Deve criar um banco de dados com nome game e executar os seguintes comandos no terminal
```bash
$ npm install
$ npm run typeorm migration:run -- -d ./src/database/typeOrm.config.ts
$ npm run start
```



